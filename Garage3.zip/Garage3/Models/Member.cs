﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Models
{
    public class Member
    {
        [Required]
        public int Id { get; set; }
        
        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        
        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
       
        [Required(ErrorMessage ="You must enter 12 digits")]
        [Display(Name = "Personal number")]
        public string PersonNr { get; set; }
        
        [Display(Name ="Pro Membership End date")]
        public DateTime MemberShipEndDate { get; set; }

        // Collection Naviagation property, e.g. One member can own many vehicles
        public ICollection<Vehicle> Vehicles { get; set; }
        


    }
}
