﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Models
{
    public class Vehicle
    {
        public int Id { get; set; }
        
        [Display(Name ="Registration Number")]
        public string RegistrationNr { get; set; }

        public string Make { get; set; }
        public string Model { get; set; }
        [Display(Name ="Number of Wheels")]
        public int NrOfWheels { get; set; }
        public DateTime ArrivalTime { get; set; }
        
        // Navigation properties for FK's, e.g. A vehicle can have only one owner
        public Member Member { get; set; }
        public VehicleType VehicleType { get; set; }
        public Garage Garage { get; set; }

      
       
    }
}
